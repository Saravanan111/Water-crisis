package com.example.watercrisis;

import java.util.Locale;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class ConDetails extends Activity {
	String database = "water.db";
	String pass,v1,v2,v3,v4,v5,v6,v7;
	Intent i = null;
	Intent in;
	Button bt_submit,bt_clear;
	String register;

	TextView t1,t2,t3,t4,t5,t6,t7,t8;
	SQLiteDatabase db;
	String sname=null;
	boolean dbfound = true;
	Cursor cursor;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_con_details);
		final Bundle getdata = getIntent().getExtras();
		if (getdata != null) {
			sname = getdata.getString("sname");

		}

		t1=(TextView)findViewById(R.id.textView1);
		t2=(TextView)findViewById(R.id.textView2);

		t3=(TextView)findViewById(R.id.textView3);

		t4=(TextView)findViewById(R.id.textView4);

		t5=(TextView)findViewById(R.id.textView5);
		


		bt_submit=(Button)findViewById(R.id.bt_add);
		bt_clear=(Button)findViewById(R.id.bt_clear);

		try {
			db = openOrCreateDatabase(database,
					SQLiteDatabase.CREATE_IF_NECESSARY, null);
			db.setVersion(1);
			db.setLocale(Locale.getDefault());
			db.setLockingEnabled(true);
			dbfound = true;

		} catch (Exception e) {
			e.printStackTrace();
			// display("Error DataBase");
		
	
		}
		bt_submit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				Intent intObj = new Intent(ConDetails.this,AdminHome.class);
				
				startActivity(intObj);
				finish();
			}			

			
		});
		Loadata(sname);

	}

public void Loadata(String sname1)
{
	Log.e("Our Details", sname1);
	cursor = db.rawQuery("select * from request where rid='"+sname1.trim()+"'", null);
	cursor.moveToFirst();

	while (!cursor.isAfterLast()) {
		v1 = cursor.getString(1);
		 v2 = cursor.getString(2);
			v3 = cursor.getString(3);
			 v4 = cursor.getString(4);
			//	v5 = cursor.getString(7);
			//	v6= cursor.getString(6);

				t1.setText("Request Details :"+v1);
				t2.setText("User Id :"+v2);
				t3.setText("Person Name :"+v3);
				t4.setText("Phone :"+v4);
				//t5.setText("Address:"+v5+"\n"+"Date :"+v6);


//		Log.i("ss", usr + " " + pas);

		// Toast.makeText(getApplicationContext(),
		// usr,Toast.LENGTH_SHORT).show();
		cursor.moveToNext();
		

	}
	cursor.close();

}
}
