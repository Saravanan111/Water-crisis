package com.example.watercrisis;

import java.util.ArrayList;
import java.util.Locale;


import android.support.v7.app.ActionBarActivity;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;

public class Complaintlist extends Activity {
	ListView listView;
	
	Intent in;
	String database = "water.db";
String loc;
	SQLiteDatabase db;
	boolean dbfound = true;
	  ArrayList<String> names=new ArrayList<String>();
	  ArrayAdapter<String> adapter;

	Cursor cursor;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_complaintlist);
	


final Bundle getdata = getIntent().getExtras();
if (getdata != null) {
	loc = getdata.getString("name");

}
//Log.e("Location", loc);

 listView = (ListView) findViewById(R.id.listview1);

 listView.setOnItemClickListener(new OnItemClickListener()
	{
		
		public void onItemClick(AdapterView<?> parent, View view, int position, long id)
		{
			
			String i=adapter.getItem(position).toString();
			// Log.i(TAG, i);
			
			 
			
			//HashMap<String, String> hm = adpt.getItem(position);
			//String selectedFromList =(String) (listView.getItemAtPosition(position));
			Intent iobj = new Intent(Complaintlist.this,CDetails.class);
			iobj.putExtra("sname",i);
	            startActivity(iobj);
		
			
			
		}
	}); 
	try {
	db = openOrCreateDatabase(database,
			SQLiteDatabase.CREATE_IF_NECESSARY, null);
	db.setVersion(1);
	db.setLocale(Locale.getDefault());
	db.setLockingEnabled(true);
	dbfound = true;

} catch (Exception e) {
	e.printStackTrace();
	// display("Error DataBase");
}

	loadSpinnerData();

}
private void loadSpinnerData() {
// database handler

names.clear();
// Spinner Drop down elements
//	List<String> lables = db.getAllLabels();
cursor = db.rawQuery("select cid from complaint", null);
cursor.moveToFirst();

while (!cursor.isAfterLast()) {
	
	String pas = cursor.getString(0);
	names.add(pas);
	Log.e("Karthick", pas);
	//  Log.i("ss", usr + " " + pas);
	// Toast.makeText(getApplicationContext(),
	// usr,Toast.LENGTH_SHORT).show();
	cursor.moveToNext();

// Creating adapter for spinner

// Drop down layout style - list view with radio button
	adapter= new ArrayAdapter<String>(this,R.layout.layout_img,R.id.name,names);
	//adapter.add(pas);
// attaching data adapter to spinner
	listView.setAdapter(adapter);
}}

}
