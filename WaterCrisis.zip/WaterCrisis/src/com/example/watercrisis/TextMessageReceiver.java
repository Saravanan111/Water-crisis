package com.example.watercrisis;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;

@SuppressLint("NewApi")
public class TextMessageReceiver extends BroadcastReceiver
{

    public void onReceive(Context context, Intent intent)
    {
	Bundle bundle = intent.getExtras();

	Object[] messages = (Object[]) bundle.get("pdus");
	SmsMessage[] sms = new SmsMessage[messages.length];

	for (int n = 0; n < messages.length; n++)
	{
	    sms[n] = SmsMessage.createFromPdu((byte[]) messages[n]);
	}

	for (SmsMessage msg : sms)
	{
	    // PulseActivity.updateMessageBox("\nFrom:   "+msg.getOriginatingAddress()+"\n\n\n\n"+"Message:  "+msg.getMessageBody()+"\n");
		try
		{	
			Log.e("Broadcast",msg.getDisplayMessageBody());
			WaterLevel.updateMessageBox( msg.getMessageBody(),msg.getOriginatingAddress());
			context.sendBroadcast(intent);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
    }
}