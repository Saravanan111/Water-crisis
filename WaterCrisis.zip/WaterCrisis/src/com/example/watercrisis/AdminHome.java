package com.example.watercrisis;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class AdminHome extends Activity {
	Button bt_complaint,bt_complaint2,bt_complaint3,bt_water;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_admin_home);
		
		bt_complaint=(Button)findViewById(R.id.bt_complaint);
		bt_complaint2=(Button)findViewById(R.id.bt_complaint2);
		
		bt_complaint3=(Button)findViewById(R.id.bt_complaint3);
		bt_water=(Button)findViewById(R.id.bt_water);

		bt_complaint.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intObj = new Intent(AdminHome.this,Complaintlist.class);
				
				startActivity(intObj);
				finish();
			}
		});
	bt_complaint2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intObj = new Intent(AdminHome.this,Conlist.class);
	
				startActivity(intObj);
				finish();
			}
		});
	bt_complaint3.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent intObj = new Intent(AdminHome.this,Paymentlist.class);
			
			startActivity(intObj);
			finish();
		}
	});
	bt_water.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent intObj = new Intent(AdminHome.this,WaterLevel.class);
			
			startActivity(intObj);
			finish();
		}
	});
	}
	}
