package com.example.watercrisis;



import java.util.Locale;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ImageUpload extends Activity {
	Button bt_submit,bt_register;
	EditText et_uname,et_upass;
	Context contxt;
	Handler handler = new Handler();
	private ProgressDialog pd;
	SQLiteDatabase db;
	boolean dbfound = true;
	String database ="water.db";
	String register;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_image_upload);
		
contxt = this;
		
		bt_submit= (Button) this.findViewById(R.id.btn_login);
		et_uname=(EditText) this.findViewById(R.id.txt_login_user);
		et_upass=(EditText) this.findViewById(R.id.txt_login_pass);
		try {
			db = openOrCreateDatabase(database,
					SQLiteDatabase.CREATE_IF_NECESSARY, null);
			db.setVersion(1);
			db.setLocale(Locale.getDefault());
			db.setLockingEnabled(true);
			dbfound = true;

			register = "create table if not exists imgupload(uid text,uname text,img blob)";
			db.execSQL(register);

		} catch (Exception e) {
			e.printStackTrace();
			// display("Error DataBase");
		}
		bt_submit.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				
				
			if(et_uname.getText().length()!=0 && et_uname.getText().length()!=0)
				{

				}
				else
				{
					Toast.makeText(getApplicationContext(), "Do not empty Username and Password", Toast.LENGTH_LONG).show();
				}
			}
		});
	
	}

	}
