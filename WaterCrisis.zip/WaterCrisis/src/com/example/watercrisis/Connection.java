package com.example.watercrisis;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Random;

import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Connection extends Activity {
	EditText a1,a2,a3,a4,a5,a6;
	String e1,e2,e3,e4,e5,e6;
	SQLiteDatabase db;
	boolean dbfound = true;
	String database ="water.db";
	String register;
	String uid=null,uname=null,address=null,phone=null;

	Button b1;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_connection);
		
		
		final Bundle getdata=getIntent().getExtras();
		if(getdata!=null){

			uid=getdata.getString("uid");
			uname=getdata.getString("uname");
			address=getdata.getString("address");
			phone=getdata.getString("phone");
		
		}

		a1=(EditText) this.findViewById(R.id.tb_update_a1);
		a2=(EditText) this.findViewById(R.id.tb_update_a2);
		a3=(EditText) this.findViewById(R.id.tb_update_a3);
		a4=(EditText) this.findViewById(R.id.tb_update_a4);
		a5=(EditText) this.findViewById(R.id.tb_update_a5);
		a6=(EditText) this.findViewById(R.id.tb_update_a6);

		b1= (Button) this.findViewById(R.id.but_update_delete);
		
		a3.setText(uid);
		a4.setText(uname);
		a5.setText(phone);
		a6.setText(address);
		Random ra = new Random();
		int n = ra.nextInt(10000);
		String a = Integer.toString(n);
		
		String val="NID"+a;
		a1.setText(val);
		try {
			db = openOrCreateDatabase(database,
					SQLiteDatabase.CREATE_IF_NECESSARY, null);
			db.setVersion(1);
			db.setLocale(Locale.getDefault());
			db.setLockingEnabled(true);
			dbfound = true;

			register = "create table if not exists request(rid text,details text,uid text,uname text,phone text,Address text,dat text)";
			db.execSQL(register);

		} catch (Exception e) {
			e.printStackTrace();
			// display("Error DataBase");
		}
		b1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				e1=a1.getText().toString();
				e2=a2.getText().toString();
				e3=a3.getText().toString();
				e4=a4.getText().toString();
				e5=a5.getText().toString();
				e6=a6.getText().toString();
				
				

				Calendar c = Calendar.getInstance();
				System.out.println("Current time => " + c.getTime());

				SimpleDateFormat df = new SimpleDateFormat("dd/MMM/yyyy");
				String formattedDate = df.format(c.getTime());

				
				if(!(e1.equalsIgnoreCase("")||e2.equalsIgnoreCase("")||e3.equalsIgnoreCase("")||e4.equalsIgnoreCase("")||e5.equalsIgnoreCase(""))){
					
					String insert="insert into request values('"+e1+"','"+e2+"','"+e3+"','"+e4+"','"+e5+"','"+e6+"','"+formattedDate+"')";
					db.execSQL(insert);

					//Toast.makeText(getApplicationContext(), a7,Toast.LENGTH_SHORT).show();
					Toast.makeText(getApplicationContext(), "" +
							"Request Added",Toast.LENGTH_LONG).show();
					
				}else{
					Toast.makeText(getApplicationContext(), "Faild",Toast.LENGTH_SHORT).show();
				}
			}
		});
	}

	}
