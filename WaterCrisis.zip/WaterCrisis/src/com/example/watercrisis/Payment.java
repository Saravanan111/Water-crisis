package com.example.watercrisis;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Random;

import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Payment extends Activity {
	String uid=null,uname=null,address=null,phone=null;
	EditText tb_update_bname,tb_update_btype,tb_update_bsrc,tb_update_bdest,tb_update_cost,tb_update_mobile,tb_update_not,tb_update_uname,tb_update_state,tb_update_country,tb_update_regid,tb_update_status;
	SQLiteDatabase db;
	boolean dbfound = true;
	String database ="water.db";
	String register;
	String e1,e2,e3,e4,e5,e6,e7;

	Button bt_submit;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_payment);
		
		final Bundle getdata=getIntent().getExtras();
		if(getdata!=null){
			
			

			uid=getdata.getString("uid");
			uname=getdata.getString("uname");
			address=getdata.getString("address");
			phone=getdata.getString("phone");
		
		}

		

		tb_update_bname=(EditText) findViewById(R.id.tb_update_bname);
		tb_update_btype=(EditText) findViewById(R.id.tb_update_btype);
		tb_update_bsrc=(EditText) findViewById(R.id.tb_update_bsrc);
		tb_update_bdest=(EditText) findViewById(R.id.tb_update_bdest);
		tb_update_not=(EditText) findViewById(R.id.tb_update_not);
		bt_submit= (Button) this.findViewById(R.id.but_update_delete);

		tb_update_bname.setText(uid);
		tb_update_btype.setText(uname);
		tb_update_bsrc.setText(address);
		tb_update_bdest.setText(phone);
		try {
			db = openOrCreateDatabase(database,
					SQLiteDatabase.CREATE_IF_NECESSARY, null);
			db.setVersion(1);
			db.setLocale(Locale.getDefault());
			db.setLockingEnabled(true);
			dbfound = true;

			register = "create table if not exists payment(pid text,uid text,uname text,phone text,address text,amt text,dat text)";
			db.execSQL(register);

		} catch (Exception e) {
			e.printStackTrace();
			// display("Error DataBase");
		}
		bt_submit.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
		
				e3=tb_update_bname.getText().toString();
				e4=tb_update_btype.getText().toString();
				e5=tb_update_bsrc.getText().toString();
				e6=tb_update_bdest.getText().toString();
				e7=tb_update_not.getText().toString();
				Calendar c = Calendar.getInstance();
				System.out.println("Current time => " + c.getTime());

				SimpleDateFormat df = new SimpleDateFormat("dd/MMM/yyyy");
				String formattedDate = df.format(c.getTime());


				
				Random ra = new Random();
				int n = ra.nextInt(10000);
				String a = Integer.toString(n);
				String val="PID"+a;
				if(!(e3.equalsIgnoreCase("")||e4.equalsIgnoreCase("")||e5.equalsIgnoreCase(""))){
					
					String insert="insert into payment values('"+val+"','"+e3+"','"+e4+"','"+e5+"','"+e6+"','"+e7+"','"+formattedDate+"')";
					db.execSQL(insert);

					//Toast.makeText(getApplicationContext(), a7,Toast.LENGTH_SHORT).show();
					Toast.makeText(getApplicationContext(), "Paid Successfully",Toast.LENGTH_LONG).show();
					
				}else{
					Toast.makeText(getApplicationContext(), "Faild",Toast.LENGTH_SHORT).show();
				}
			}
		});

	}
	 protected void sendSMSMessage() {
	      Log.i("Send SMS", "");

	      String phoneNo =tb_update_bsrc.getText().toString();;
	String message="Your Payment Successfuly generated";
	      Log.v("mobile",phoneNo);
 // SMS sm=new SMS();
    //   sm.SendSMS(phoneNo, message);
	      String pmno="9944589861";
	  try {
	         SmsManager smsManager = SmsManager.getDefault();
	         smsManager.sendTextMessage(phoneNo, null, message, null, null);
	         smsManager.sendTextMessage(pmno, null, "This User"+uid+""+"uname"+"Payment Success today", null, null);
	         Toast.makeText(getApplicationContext(), "SMS Send.",
	         Toast.LENGTH_LONG).show();
	      } catch (Exception e) {
	         Toast.makeText(getApplicationContext(),
	         "SMS faild, please try again.",
	         Toast.LENGTH_LONG).show();
	         e.printStackTrace();
	      }
	   }
	}
