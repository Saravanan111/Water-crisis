package com.example.watercrisis;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class Home extends Activity {
	Button bt_attence,bt_mark,bt_payment;
String uid=null,uname=null,address=null,phone=null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home);
		final Bundle getdata=getIntent().getExtras();
		if(getdata!=null){
			uid=getdata.getString("uid");
			uname=getdata.getString("uname");
			address=getdata.getString("address");
			phone=getdata.getString("phone");

		
		}
		bt_attence=(Button)findViewById(R.id.bt_attance);
		bt_mark=(Button)findViewById(R.id.bt_mark);
		
		bt_payment=(Button)findViewById(R.id.bt_payment);

		
		bt_attence.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				Intent intObj= new Intent(Home.this,AddComplaint.class);
				intObj.putExtra("uname",uname);
				intObj.putExtra("phone",phone);
				intObj.putExtra("uid",uid);
				intObj.putExtra("address",address);

				startActivity(intObj);
				finish();
			}
		});
		bt_mark.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				Intent intObj = new Intent(Home.this,Connection.class);
				//intObj1.putExtra("name",et_uname.getText().toString());
				intObj.putExtra("uname",uname);
				intObj.putExtra("phone",phone);
				intObj.putExtra("uid",uid);
				intObj.putExtra("address",address);

				startActivity(intObj);
				finish();
			}
		});
		
		bt_payment.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				//intObj1.putExtra("name",et_uname.getText().toString());
				Intent intObj = new Intent(Home.this,Payment.class);
				intObj.putExtra("uname",uname);
				intObj.putExtra("phone",phone);
				intObj.putExtra("uid",uid);
				intObj.putExtra("address",address);
				startActivity(intObj);
				finish();
			}
		});
}
}