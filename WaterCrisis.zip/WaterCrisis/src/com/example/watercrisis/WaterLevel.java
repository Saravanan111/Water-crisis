package com.example.watercrisis;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class WaterLevel extends Activity {
	static String mob="";
	static String n="9445412354";
	static String msg,no="";
	static Context contxt;
	private static TextView t4,t3,t5;
	Button bt_add;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		contxt = getApplicationContext();

		setContentView(R.layout.activity_water_level);
		t4=(TextView)findViewById(R.id.textView4);
		t3=(TextView)findViewById(R.id.textView3);
		t5=(TextView)findViewById(R.id.textView5);

		bt_add=(Button)findViewById(R.id.bt_add);
		
		t4.setVisibility(View.GONE);
		t5.setVisibility(View.GONE);
		t3.setVisibility(View.GONE);

		bt_add.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent iobj = new Intent(WaterLevel.this,AdminHome.class);
		            startActivity(iobj);
			}
		});
	}

		public static  void updateMessageBox(String msg,String no)
	{
			t4.setText("");
		mob=msg;
		n=no;
		Toast.makeText(contxt, mob.toString(), Toast.LENGTH_LONG).show();
			if(mob.startsWith("*1"))
		{
				t4.setVisibility(View.VISIBLE);
				t4.setText("Gandhipuram");
				t3.setVisibility(View.GONE);
				t5.setVisibility(View.GONE);

//			String t=mob.substring(1,5);
//				//tem.setText(t);
//			//set location
//			String	slat = mob.substring(1, 9);


		}			else if(mob.startsWith("*2"))
		{
			t3.setVisibility(View.VISIBLE);

			t3.setText("Ganapathy");
			t4.setVisibility(View.GONE);
			t5.setVisibility(View.GONE);

//			String t=mob.substring(1,5);
//				//tem.setText(t);
//			//set location
//			String	slat = mob.substring(1, 9);


		}		else if(mob.startsWith("*3"))
		{				
			t5.setVisibility(View.VISIBLE);

			
			t5.setText("Peelamaedu");
			t3.setVisibility(View.GONE);
			t4.setVisibility(View.GONE);

//			String t=mob.substring(1,5);
//				//tem.setText(t);
//			//set location
//			String	slat = mob.substring(1, 9);


		}			else if(mob.startsWith("*"))
		{
			t4.setText("Area1");

//			String t=mob.substring(1,5);
//				//tem.setText(t);
//			//set location
//			String	slat = mob.substring(1, 9);


		}

		 else{
			 Toast.makeText(contxt, "Location Error", Toast.LENGTH_LONG).show();
		 }

	}

}
